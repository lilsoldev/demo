import Autopool from './autopool'
import abi from './abi.json'

const contractAddress = '0x8abAe1D59ea33A709a891A69403340D8E32b98de'
const gnetId = 3

const onReady = async ({ web3, contract, wallet, ownerWallet, contractAddress }) => {
  const { eth, utils } = web3
  document.getElementById('contract-address').innerHTML = contractAddress
  document.getElementById('owner-wallet').innerHTML = ownerWallet
  document.getElementById('wallet').innerHTML = wallet
  document.getElementById('balance').innerHTML = await autopool.getBalance(wallet)
  ;(function loop() {
    setTimeout(async () => {
      const { user, address } = await autopool.getTopReferral()
      document.getElementById('top-address').innerHTML = address
      document.getElementById('referred-users').innerHTML = user.referredUsers
      loop()
    }, 500)
  })()
}

const onWalletChange = async (wallet) => {
  document.getElementById('wallet').innerHTML = wallet
  document.getElementById('balance').innerHTML = await autopool.getBalance(wallet)
}

const onError = (error) => alert(error)

const autopool = new Autopool({ contractAddress, gnetId, abi, onReady, onError, onWalletChange })
