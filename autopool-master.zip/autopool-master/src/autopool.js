import Web3 from 'web3'

class Autopool {
  constructor(props) {
    const { contractAddress, gnetId = 3, abi, onReady, onError, onWalletChange } = props

    this.contractAddress = contractAddress
    this.gnetId = gnetId
    this.abi = abi
    this.onReady = onReady || (() => console.log('onReady from class'))
    this.onError = onError || ((error) => alert(error))
    this.onWalletChange =
      onWalletChange || ((wallet) => console.log('wallet changed from class', wallet))
    this.setup().then(this.onReady)
  }

  async setup() {
    this.web3 = await this.checkNet()
    this.contract = await this.handlerWeb3(this.web3)
    this.wallet = await this.checkLogin(this.web3)
    this.ownerWallet = await this.contract.methods.ownerWallet().call()
    setInterval(
      () =>
        this.checkLogin(this.web3).then((wallet) => {
          if (this.wallet !== wallet) {
            this.wallet = wallet
            this.onWalletChange(wallet)
          }
        }),
      200
    )
    const { web3, contract, wallet, ownerWallet, contractAddress } = this
    return { web3, contract, wallet, ownerWallet, contractAddress }
  }

  async checkLogin(web3) {
    const accounts = await this.web3.eth.getAccounts()
    return accounts[0]
  }

  async checkNet() {
    const { ethereum } = window
    let web3
    if (ethereum) {
      web3 = new Web3(ethereum)
      await ethereum.enable().catch((error) => this.onError(error))
    } else if (window.web3) {
      web3 = new Web3(web3.currentProvider)
    } else {
      this.onError('Please download iMToken or Metamask or Trustwallet...')
    }
    this.web3 = web3
    return web3
  }

  handlerWeb3() {
    const { gnetId, web3 } = this
    const contract = new web3.eth.Contract(this.abi, this.contractAddress)
    web3.eth.net.getId(function (err, netId) {
      if (netId !== gnetId) {
        if (gnetId === 3 || gnetId === 4) this.onError('User Select TestNet!')
        if (gnetId === 1) this.onError('Please Select MainNet!')
      }
    })
    return contract
  }

  async getBalance(wallet = this.wallet, currency = 'ether') {
    const { eth, utils } = this.web3
    const wei = await eth.getBalance(wallet)
    return utils.fromWei(wei, currency)
  }

  async getTopReferral() {
    const { getTopReferralAddress, users } = this.contract.methods
    const address = await getTopReferralAddress().call()
    const user = await users(address).call()
    return { address, user }
  }
}

window.Autopool = Autopool

export default Autopool
