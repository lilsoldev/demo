# Autopool

## Setup
`$ git clone git@github.com:andrepadez/autopool.git`
`$ cd autopool`
`$ yarn`

## Running the demo
`$ yarn dev`

## Building for usage
`$ yarn build`
- the file is located at `./dist/autopool.js`
- copy it to your project and include it in a script tag
- the Autopool class is accessible through the window

## How to use Autopool
- run the demo and check the `src/main.js` for example

### Todos:
- improve the Autopool class so managing the web3 connection to the contract is optional
